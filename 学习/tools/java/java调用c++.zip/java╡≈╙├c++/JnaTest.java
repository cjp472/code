package com.koorun.test;

import com.sun.jna.Library;
import com.sun.jna.Native;

import java.io.UnsupportedEncodingException;

public class JnaTest {

	public static void main(String[] args) throws UnsupportedEncodingException {

		//1.加载 DLL路径
		String PATH = JnaTest.class.getClassLoader().getResource("").getPath();
		if(PATH.startsWith("/")){
			PATH = PATH.substring(1, PATH.length());
		}
		String RDR_DLL_PATH = PATH + "dll/MisPos";

		R24GInterface RDR_INSTANCE = (R24GInterface) Native.loadLibrary(RDR_DLL_PATH, R24GInterface.class);
        //"02^0^" + Home.Increase_xNumber(money,"0",12) + "^11234567890123456^", OutData
		//2.调用DLL方法
        byte [] out = new byte[514];
		System.out.println(RDR_INSTANCE.PCharMisPosInterface("02^0^0000000000001^11234567890123456^",out));
		String str = new String(out,"gbk");
		System.out.println(str);
	}

}
interface R24GInterface extends Library {
    int PCharMisPosInterface(String cin,byte[] out);
    String test(String str , int aa);
//

}